// Exercises Database
class ExercisesDatabase {
    constructor() {
        this.exercises = [
            // Chest Exercises
            {
                id: 1,
                name: 'پرس سینه با دمبل',
                nameEn: 'Dumbbell Bench Press',
                muscleGroup: 'chest',
                difficulty: 'beginner',
                equipment: 'دمبل، نیمکت',
                description: 'تمرین اصلی برای تقویت عضلات سینه با استفاده از دمبل',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: true,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 2,
                name: 'پرس سینه با هالتر',
                nameEn: 'Barbell Bench Press',
                muscleGroup: 'chest',
                difficulty: 'intermediate',
                equipment: 'هالتر، نیمکت پرس',
                description: 'تمرین پایه برای رشد عضلات سینه و سه سر',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: true,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 3,
                name: 'پرس سینه شیب‌دار',
                nameEn: 'Incline Bench Press',
                muscleGroup: 'chest',
                difficulty: 'intermediate',
                equipment: 'هالتر، نیمکت شیب‌دار',
                description: 'تمرین برای قسمت بالایی سینه',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: true,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 4,
                name: 'پرس سینه دمبل روی زمین',
                nameEn: 'Floor Press',
                muscleGroup: 'chest',
                difficulty: 'beginner',
                equipment: 'دمبل',
                description: 'تمرین امن برای کسانی که مشکل شانه دارند',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 5,
                name: 'پوش‌آپ',
                nameEn: 'Push-ups',
                muscleGroup: 'chest',
                difficulty: 'beginner',
                equipment: 'بدون وسیله',
                description: 'تمرین بدن وزن برای سینه، شانه و بازو',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },

            // Back Exercises
            {
                id: 6,
                name: 'ددلیفت',
                nameEn: 'Deadlift',
                muscleGroup: 'back',
                difficulty: 'advanced',
                equipment: 'هالتر، وزنه',
                description: 'تمرین ترکیبی برای کل بدن، مخصوصاً پشت و پا',
                avoidWithBackPain: true,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: true,
                videoUrl: null
            },
            {
                id: 7,
                name: 'پulling روی میله',
                nameEn: 'Pull-ups',
                muscleGroup: 'back',
                difficulty: 'intermediate',
                equipment: 'میله بارفیکس',
                description: 'تمرین عالی برای عضلات پشت و بی‌سپ',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: true,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 8,
                name: 'زیر بغل با هالتر',
                nameEn: 'Bent-over Row',
                muscleGroup: 'back',
                difficulty: 'intermediate',
                equipment: 'هالتر',
                description: 'تمرین برای عضلات میانی پشت',
                avoidWithBackPain: true,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 9,
                name: 'زیر بغل دمبل یک دست',
                nameEn: 'Single-arm Dumbbell Row',
                muscleGroup: 'back',
                difficulty: 'beginner',
                equipment: 'دمبل',
                description: 'تمرین انفرادی برای هر طرف پشت',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 10,
                name: 'پاور کلین',
                nameEn: 'Power Clean',
                muscleGroup: 'back',
                difficulty: 'advanced',
                equipment: 'هالتر، وزنه',
                description: 'تمرین انفجاری برای کل بدن',
                avoidWithBackPain: true,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: true,
                videoUrl: null
            },

            // Shoulders Exercises
            {
                id: 11,
                name: 'پرس شانه ایستاده',
                nameEn: 'Overhead Press',
                muscleGroup: 'shoulders',
                difficulty: 'intermediate',
                equipment: 'هالتر',
                description: 'تمرین اصلی برای شانه‌های جلو',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: true,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 12,
                name: 'پرس شانه با دمبل',
                nameEn: 'Dumbbell Shoulder Press',
                muscleGroup: 'shoulders',
                difficulty: 'beginner',
                equipment: 'دمبل، صندلی',
                description: 'تمرین کنترل شده برای شانه‌ها',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 13,
                name: 'جلو بازو دمبل',
                nameEn: 'Lateral Raises',
                muscleGroup: 'shoulders',
                difficulty: 'beginner',
                equipment: 'دمبل',
                description: 'تمرین برای شانه‌های جانبی',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 14,
                name: 'پشت بازو دمبل',
                nameEn: 'Rear Delt Flyes',
                muscleGroup: 'shoulders',
                difficulty: 'beginner',
                equipment: 'دمبل',
                description: 'تمرین برای شانه‌های عقبی',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 15,
                name: 'پرس آرنولد',
                nameEn: 'Arnold Press',
                muscleGroup: 'shoulders',
                difficulty: 'intermediate',
                equipment: 'دمبل',
                description: 'تمرین ترکیبی برای شانه‌ها',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: true,
                highIntensity: false,
                videoUrl: null
            },

            // Arms Exercises
            {
                id: 16,
                name: 'جلو بازو با هالتر',
                nameEn: 'Barbell Bicep Curls',
                muscleGroup: 'arms',
                difficulty: 'beginner',
                equipment: 'هالتر',
                description: 'تمرین اصلی برای عضلات دو سر بازو',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 17,
                name: 'جلو بازو با دمبل',
                nameEn: 'Dumbbell Bicep Curls',
                muscleGroup: 'arms',
                difficulty: 'beginner',
                equipment: 'دمبل',
                description: 'تمرین انفرادی برای هر دست',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 18,
                name: 'جلو بازو چکشی',
                nameEn: 'Hammer Curls',
                muscleGroup: 'arms',
                difficulty: 'beginner',
                equipment: 'دمبل',
                description: 'تمرین برای عضلات دو سر و بازوی پشتی',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 19,
                name: 'پشت بازو با هالتر',
                nameEn: 'Tricep Pushdowns',
                muscleGroup: 'arms',
                device: 'کابل',
                difficulty: 'beginner',
                equipment: 'دستگاه کابل',
                description: 'تمرین برای عضلات پشتی بازو',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 20,
                name: 'پشت بازو دمبل',
                nameEn: 'Overhead Tricep Extensions',
                muscleGroup: 'arms',
                difficulty: 'beginner',
                equipment: 'دمبل',
                description: 'تمرین برای عضلات پشتی بازو با دمبل',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 21,
                name: 'دیپ روی نیمکت',
                nameEn: 'Bench Dips',
                muscleGroup: 'arms',
                difficulty: 'intermediate',
                equipment: 'نیمکت',
                description: 'تمرین برای عضلات پشتی بازو',
                avoidWithBackPain: false,
                avoidWithKneeProblems: true,
                avoidWithShoulderInjury: true,
                highIntensity: false,
                videoUrl: null
            },

            // Legs Exercises
            {
                id: 22,
                name: 'اسکات با هالتر',
                nameEn: 'Barbell Squats',
                muscleGroup: 'legs',
                difficulty: 'intermediate',
                equipment: 'هالتر، رک',
                description: 'تمرین پادشاه برای پاها و باسن',
                avoidWithBackPain: false,
                avoidWithKneeProblems: true,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 23,
                name: 'اسکات با دمبل',
                nameEn: 'Goblet Squats',
                muscleGroup: 'legs',
                difficulty: 'beginner',
                equipment: 'دمبل سنگین',
                description: 'نسخه امن‌تر اسکات برای مبتدیان',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 24,
                name: 'لیفت پا با دمبل',
                nameEn: 'Romanian Deadlifts',
                muscleGroup: 'legs',
                difficulty: 'intermediate',
                equipment: 'دمبل',
                description: 'تمرین برای پشت ران و باسن',
                avoidWithBackPain: true,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 25,
                name: 'پرس پا',
                nameEn: 'Leg Press',
                muscleGroup: 'legs',
                difficulty: 'beginner',
                equipment: 'دستگاه پرس پا',
                description: 'تمرین امن برای ران و باسن',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 26,
                name: 'لانگ با دمبل',
                nameEn: 'Dumbbell Lunges',
                muscleGroup: 'legs',
                difficulty: 'beginner',
                equipment: 'دمبل',
                description: 'تمرین تک‌پا برای پاها',
                avoidWithBackPain: false,
                avoidWithKneeProblems: true,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 27,
                name: 'پشت ران با دستگاه',
                nameEn: 'Leg Curls',
                muscleGroup: 'legs',
                difficulty: 'beginner',
                equipment: 'دستگاه پشت ران',
                description: 'تمرین مخصوص عضلات پشت ران',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 28,
                name: 'ساق پا ایستاده',
                nameEn: 'Standing Calf Raises',
                muscleGroup: 'legs',
                difficulty: 'beginner',
                equipment: 'بدون وسیله یا دمبل',
                description: 'تمرین برای عضلات ساق پا',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },

            // Core Exercises
            {
                id: 29,
                name: 'کرانچ شکم',
                nameEn: 'Ab Crunches',
                muscleGroup: 'core',
                difficulty: 'beginner',
                equipment: 'بدون وسیله',
                description: 'تمرین پایه برای عضلات شکم',
                avoidWithBackPain: true,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 30,
                name: 'پلانک',
                nameEn: 'Plank',
                muscleGroup: 'core',
                difficulty: 'beginner',
                equipment: 'بدون وسیله',
                description: 'تمرین ایزومتریک برای کل هسته بدن',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 31,
                name: 'پلانک جانبی',
                nameEn: 'Side Plank',
                muscleGroup: 'core',
                difficulty: 'intermediate',
                equipment: 'بدون وسیله',
                description: 'تمرین برای عضلات جانبی شکم',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 32,
                name: 'دراز و نشست',
                nameEn: 'Sit-ups',
                muscleGroup: 'core',
                difficulty: 'beginner',
                equipment: 'بدون وسیله',
                description: 'تمرین کلاسیک شکم',
                avoidWithBackPain: true,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 33,
                name: 'ددلیفت با پا',
                nameEn: 'Leg Raises',
                muscleGroup: 'core',
                difficulty: 'intermediate',
                equipment: 'بدون وسیله یا پارالل',
                description: 'تمرین برای عضلات پایینی شکم',
                avoidWithBackPain: false,
                avoidWithKneeProblems: false,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },

            // Cardio Exercises
            {
                id: 34,
                name: 'دو آرام',
                nameEn: 'Easy Jogging',
                muscleGroup: 'full-body',
                difficulty: 'beginner',
                equipment: 'بدون وسیله',
                description: 'تمرین کاردیو ملایم',
                avoidWithBackPain: false,
                avoidWithKneeProblems: true,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 35,
                name: 'پرش جفت',
                nameEn: 'Jumping Jacks',
                muscleGroup: 'full-body',
                difficulty: 'beginner',
                equipment: 'بدون وسیله',
                description: 'تمرین کاردیو برای کل بدن',
                avoidWithBackPain: false,
                avoidWithKneeProblems: true,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            },
            {
                id: 36,
                name: 'burpee',
                nameEn: 'Burpees',
                muscleGroup: 'full-body',
                difficulty: 'intermediate',
                equipment: 'بدون وسیله',
                description: 'تمرین شدید کل بدن',
                avoidWithBackPain: true,
                avoidWithKneeProblems: true,
                avoidWithShoulderInjury: true,
                highIntensity: true,
                videoUrl: null
            },
            {
                id: 37,
                name: 'کوهنورد',
                nameEn: 'Mountain Climbers',
                muscleGroup: 'full-body',
                difficulty: 'intermediate',
                equipment: 'بدون وسیله',
                description: 'تمرین کاردیو و قدرتی',
                avoidWithBackPain: false,
                avoidWithKneeProblems: true,
                avoidWithShoulderInjury: false,
                highIntensity: false,
                videoUrl: null
            }
        ];
    }

    getAllExercises() {
        return this.exercises;
    }

    getExercisesByMuscleGroup(muscleGroup) {
        return this.exercises.filter(exercise => exercise.muscleGroup === muscleGroup);
    }

    getExerciseByName(name) {
        return this.exercises.find(exercise => exercise.name === name);
    }

    getCardioExercises() {
        return this.exercises.filter(exercise => 
            exercise.muscleGroup === 'full-body' && exercise.highIntensity === false
        );
    }

    getExercisesByDifficulty(difficulty) {
        return this.exercises.filter(exercise => exercise.difficulty === difficulty);
    }

    getExercisesByEquipment(equipment) {
        return this.exercises.filter(exercise => exercise.equipment === equipment);
    }

    searchExercises(query) {
        const searchTerm = query.toLowerCase();
        return this.exercises.filter(exercise => 
            exercise.name.toLowerCase().includes(searchTerm) ||
            exercise.nameEn.toLowerCase().includes(searchTerm) ||
            exercise.description.toLowerCase().includes(searchTerm)
        );
    }

    getExercisesSafeForHealthConditions(healthConditions) {
        let filteredExercises = this.exercises;

        if (healthConditions.includes('back-pain')) {
            filteredExercises = filteredExercises.filter(ex => !ex.avoidWithBackPain);
        }

        if (healthConditions.includes('knee-problems')) {
            filteredExercises = filteredExercises.filter(ex => !ex.avoidWithKneeProblems);
        }

        if (healthConditions.includes('shoulder-injury')) {
            filteredExercises = filteredExercises.filter(ex => !ex.avoidWithShoulderInjury);
        }

        if (healthConditions.includes('heart-condition')) {
            filteredExercises = filteredExercises.filter(ex => !ex.highIntensity);
        }

        return filteredExercises;
    }
}

// Make ExercisesDatabase available globally
window.ExercisesDatabase = new ExercisesDatabase();