// Progress Charts Handler
class ProgressCharts {
    constructor() {
        this.chart = null;
        this.init();
    }

    init() {
        this.setupCanvas();
        this.setupChartStyles();
    }

    setupCanvas() {
        const canvas = document.getElementById('progress-chart');
        if (!canvas) return;

        // Set canvas size based on container
        const container = canvas.parentElement;
        const containerWidth = container.offsetWidth;
        
        canvas.width = Math.max(400, containerWidth - 40);
        canvas.height = 300;

        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
    }

    setupChartStyles() {
        if (!this.ctx) return;

        // Set default styles
        this.ctx.font = '14px Vazirmatn, Arial, sans-serif';
        this.ctx.textAlign = 'right';
        this.ctx.textBaseline = 'middle';
    }

    updateChart(data) {
        if (!this.canvas || !this.ctx || data.length === 0) return;

        this.clearCanvas();
        this.drawChart(data);
    }

    clearCanvas() {
        if (!this.ctx || !this.canvas) return;
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }

    drawChart(data) {
        const ctx = this.ctx;
        const canvas = this.canvas;
        
        // Chart dimensions
        const padding = 60;
        const chartWidth = canvas.width - (padding * 2);
        const chartHeight = canvas.height - (padding * 2);

        // Find min and max values
        const weights = data.map(d => d.weight);
        const minWeight = Math.min(...weights) - 2;
        const maxWeight = Math.max(...weights) + 2;
        const weightRange = maxWeight - minWeight;

        // Draw grid lines
        this.drawGridLines(ctx, padding, chartWidth, chartHeight, minWeight, maxWeight);

        // Draw axes
        this.drawAxes(ctx, padding, chartWidth, chartHeight);

        // Draw data points and lines
        this.drawDataLine(ctx, data, padding, chartWidth, chartHeight, minWeight, weightRange);
        this.drawDataPoints(ctx, data, padding, chartWidth, chartHeight, minWeight, weightRange);

        // Draw labels
        this.drawLabels(ctx, data, padding, chartWidth, chartHeight, minWeight, maxWeight);
    }

    drawGridLines(ctx, padding, chartWidth, chartHeight, minWeight, maxWeight) {
        const weightRange = maxWeight - minWeight;
        const ySteps = 5;
        
        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 1;

        // Horizontal lines
        for (let i = 0; i <= ySteps; i++) {
            const y = padding + (chartHeight / ySteps) * i;
            ctx.beginPath();
            ctx.moveTo(padding, y);
            ctx.lineTo(padding + chartWidth, y);
            ctx.stroke();
        }

        // Vertical lines
        const xSteps = Math.min(data.length - 1, 6);
        for (let i = 0; i <= xSteps; i++) {
            const x = padding + (chartWidth / xSteps) * i;
            ctx.beginPath();
            ctx.moveTo(x, padding);
            ctx.lineTo(x, padding + chartHeight);
            ctx.stroke();
        }
    }

    drawAxes(ctx, padding, chartWidth, chartHeight) {
        ctx.strokeStyle = '#333';
        ctx.lineWidth = 2;

        // Y-axis
        ctx.beginPath();
        ctx.moveTo(padding, padding);
        ctx.lineTo(padding, padding + chartHeight);
        ctx.stroke();

        // X-axis
        ctx.beginPath();
        ctx.moveTo(padding, padding + chartHeight);
        ctx.lineTo(padding + chartWidth, padding + chartHeight);
        ctx.stroke();

        // Axis labels
        ctx.fillStyle = '#333';
        ctx.font = 'bold 14px Vazirmatn, Arial, sans-serif';
        ctx.textAlign = 'center';

        // Y-axis label
        ctx.save();
        ctx.translate(20, padding + chartHeight / 2);
        ctx.rotate(-Math.PI / 2);
        ctx.fillText('وزن (کیلوگرم)', 0, 0);
        ctx.restore();

        // X-axis label
        ctx.fillText('تاریخ', padding + chartWidth / 2, padding + chartHeight + 40);
    }

    drawDataLine(ctx, data, padding, chartWidth, chartHeight, minWeight, weightRange) {
        if (data.length < 2) return;

        ctx.strokeStyle = '#2196F3';
        ctx.lineWidth = 3;
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';

        ctx.beginPath();
        
        data.forEach((point, index) => {
            const x = padding + (chartWidth / (data.length - 1)) * index;
            const y = padding + chartHeight - ((point.weight - minWeight) / weightRange) * chartHeight;
            
            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });

        ctx.stroke();

        // Fill area under the curve
        ctx.fillStyle = 'rgba(33, 150, 243, 0.1)';
        ctx.beginPath();
        ctx.moveTo(padding, padding + chartHeight);
        
        data.forEach((point, index) => {
            const x = padding + (chartWidth / (data.length - 1)) * index;
            const y = padding + chartHeight - ((point.weight - minWeight) / weightRange) * chartHeight;
            ctx.lineTo(x, y);
        });
        
        ctx.lineTo(padding + chartWidth, padding + chartHeight);
        ctx.closePath();
        ctx.fill();
    }

    drawDataPoints(ctx, data, padding, chartWidth, chartHeight, minWeight, weightRange) {
        data.forEach((point, index) => {
            const x = padding + (chartWidth / (data.length - 1)) * index;
            const y = padding + chartHeight - ((point.weight - minWeight) / weightRange) * chartHeight;

            // Draw point circle
            ctx.fillStyle = '#2196F3';
            ctx.beginPath();
            ctx.arc(x, y, 6, 0, 2 * Math.PI);
            ctx.fill();

            // Draw white border
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2;
            ctx.stroke();

            // Draw weight value above point (for last point only)
            if (index === data.length - 1) {
                ctx.fillStyle = '#333';
                ctx.font = 'bold 12px Vazirmatn, Arial, sans-serif';
                ctx.textAlign = 'center';
                ctx.fillText(`${point.weight} کگ`, x, y - 15);
            }
        });
    }

    drawLabels(ctx, data, padding, chartWidth, chartHeight, minWeight, maxWeight) {
        ctx.fillStyle = '#666';
        ctx.font = '12px Vazirmatn, Arial, sans-serif';
        ctx.textAlign = 'center';

        // Y-axis labels (weights)
        const ySteps = 5;
        for (let i = 0; i <= ySteps; i++) {
            const weight = minWeight + (maxWeight - minWeight) * (i / ySteps);
            const y = padding + chartHeight - (chartHeight / ySteps) * i;
            
            ctx.fillText(weight.toFixed(1), padding - 10, y);
        }

        // X-axis labels (dates)
        const maxLabels = Math.min(data.length, 6);
        for (let i = 0; i < maxLabels; i++) {
            const index = Math.floor((data.length - 1) * (i / (maxLabels - 1)));
            const date = data[index];
            const x = padding + (chartWidth / (data.length - 1)) * index;
            
            // Format date for display
            const dateStr = date.date.toLocaleDateString('fa-IR', { 
                month: 'numeric', 
                day: 'numeric' 
            });
            
            ctx.save();
            ctx.translate(x, padding + chartHeight + 15);
            ctx.rotate(-Math.PI / 6);
            ctx.fillText(dateStr, 0, 0);
            ctx.restore();
        }
    }

    // Create mini chart for dashboard
    createMiniChart(data, canvasId, color = '#2196F3') {
        const canvas = document.getElementById(canvasId);
        if (!canvas || data.length === 0) return;

        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        const padding = 20;

        // Clear canvas
        ctx.clearRect(0, 0, width, height);

        // Calculate scaling
        const weights = data.map(d => d.weight);
        const minWeight = Math.min(...weights);
        const maxWeight = Math.max(...weights);
        const weightRange = maxWeight - minWeight || 1;

        // Draw line
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';

        ctx.beginPath();
        data.forEach((point, index) => {
            const x = padding + ((width - padding * 2) / (data.length - 1)) * index;
            const y = padding + height - padding - ((point.weight - minWeight) / weightRange) * (height - padding * 2);
            
            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });
        ctx.stroke();

        // Draw points
        data.forEach((point, index) => {
            const x = padding + ((width - padding * 2) / (data.length - 1)) * index;
            const y = padding + height - padding - ((point.weight - minWeight) / weightRange) * (height - padding * 2);
            
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, 2 * Math.PI);
            ctx.fill();
        });
    }

    // Export chart as image
    exportChartAsImage(filename = 'progress-chart.png') {
        if (!this.canvas) return;

        try {
            const link = document.createElement('a');
            link.download = filename;
            link.href = this.canvas.toDataURL('image/png');
            link.click();
        } catch (error) {
            console.error('Failed to export chart:', error);
        }
    }

    // Calculate statistics
    calculateStats(data) {
        if (data.length === 0) return null;

        const weights = data.map(d => d.weight);
        const firstWeight = weights[0];
        const lastWeight = weights[weights.length - 1];
        const totalChange = lastWeight - firstWeight;
        const averageWeight = weights.reduce((sum, weight) => sum + weight, 0) / weights.length;

        return {
            totalChange,
            averageWeight,
            firstWeight,
            lastWeight,
            dataPoints: data.length
        };
    }

    // Create trend analysis
    analyzeTrend(data) {
        if (data.length < 2) return { trend: 'insufficient-data', direction: null };

        const weights = data.map(d => d.weight);
        const firstHalf = weights.slice(0, Math.floor(weights.length / 2));
        const secondHalf = weights.slice(Math.floor(weights.length / 2));

        const firstAvg = firstHalf.reduce((sum, w) => sum + w, 0) / firstHalf.length;
        const secondAvg = secondHalf.reduce((sum, w) => sum + w, 0) / secondHalf.length;

        const change = secondAvg - firstAvg;
        const percentChange = (change / firstAvg) * 100;

        let trend, direction;
        if (Math.abs(percentChange) < 2) {
            trend = 'stable';
            direction = 'stable';
        } else if (percentChange > 2) {
            trend = 'increasing';
            direction = 'up';
        } else {
            trend = 'decreasing';
            direction = 'down';
        }

        return {
            trend,
            direction,
            change: change.toFixed(1),
            percentChange: percentChange.toFixed(1)
        };
    }
}

// Make ProgressCharts available globally
window.ProgressCharts = new ProgressCharts();