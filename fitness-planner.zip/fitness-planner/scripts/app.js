// Main App Controller
class FitnessApp {
    constructor() {
        this.currentUser = null;
        this.currentPlan = null;
        this.progressData = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadUserData();
        this.setupPWA();
        this.hideLoadingScreen();
    }

    hideLoadingScreen() {
        setTimeout(() => {
            const loadingScreen = document.getElementById('loading-screen');
            const app = document.getElementById('app');
            
            if (loadingScreen && app) {
                loadingScreen.style.display = 'none';
                app.classList.remove('hidden');
            }
        }, 1000);
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const section = e.currentTarget.dataset.section;
                this.switchSection(section);
            });
        });

        // Profile form
        const profileForm = document.getElementById('profile-form');
        if (profileForm) {
            profileForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleProfileSubmit();
            });
        }

        // Progress form
        const progressForm = document.getElementById('progress-form');
        if (progressForm) {
            progressForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleProgressSubmit();
            });
        }

        // PDF Download
        const downloadBtn = document.getElementById('download-pdf');
        if (downloadBtn) {
            downloadBtn.addEventListener('click', () => {
                this.downloadPDF();
            });
        }

        // Exercise filters
        const bodyPartFilter = document.getElementById('body-part-filter');
        if (bodyPartFilter) {
            bodyPartFilter.addEventListener('change', (e) => {
                this.filterExercises(e.target.value);
            });
        }

        // Day workout expand/collapse
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('day-header') || e.target.closest('.day-header')) {
                const dayContent = e.target.closest('.day-workout').querySelector('.day-content');
                dayContent.classList.toggle('active');
            }
        });
    }

    switchSection(sectionName) {
        // Update navigation
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');

        // Update content
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(`${sectionName}-section`).classList.add('active');

        // Section specific initialization
        switch (sectionName) {
            case 'plan':
                this.displayPlan();
                break;
            case 'exercises':
                this.displayExercises();
                break;
            case 'progress':
                this.displayProgress();
                break;
        }
    }

    handleProfileSubmit() {
        const formData = new FormData(document.getElementById('profile-form'));
        const userData = {};

        // Collect basic data
        userData.name = formData.get('name');
        userData.age = parseInt(formData.get('age'));
        userData.height = parseInt(formData.get('height'));
        userData.weight = parseInt(formData.get('weight'));
        userData.gender = formData.get('gender');
        userData.goal = formData.get('goal');
        userData.experience = formData.get('experience');
        userData.daysPerWeek = parseInt(formData.get('days-per-week'));
        userData.duration = parseInt(formData.get('duration'));
        userData.activityLevel = formData.get('activity-level');

        // Collect health conditions
        const healthConditions = [];
        document.querySelectorAll('input[name="health-conditions"]:checked').forEach(checkbox => {
            healthConditions.push(checkbox.value);
        });
        userData.healthConditions = healthConditions;

        // Additional notes
        userData.additionalNotes = formData.get('additional-notes');

        // Calculate BMI
        userData.bmi = this.calculateBMI(userData.weight, userData.height);

        // Save user data
        this.currentUser = userData;
        this.saveUserData();

        // Generate workout plan
        this.currentPlan = new WorkoutPlanner(userData).generatePlan();

        // Show success message
        this.showToast('برنامه تمرینی شما با موفقیت ایجاد شد!', 'success');

        // Switch to plan section
        setTimeout(() => {
            this.switchSection('plan');
        }, 1500);
    }

    handleProgressSubmit() {
        const weight = parseFloat(document.getElementById('progress-weight').value);
        const date = document.getElementById('progress-date').value;
        const dateObj = new Date(date);

        if (weight && date) {
            this.progressData.push({
                date: dateObj,
                weight: weight,
                bmi: this.calculateBMI(weight, this.currentUser?.height || 0)
            });

            // Sort by date
            this.progressData.sort((a, b) => a.date - b.date);
            
            // Save progress data
            this.saveProgressData();
            
            // Update display
            this.displayProgress();
            
            // Clear form
            document.getElementById('progress-form').reset();
            
            this.showToast('اطلاعات پیشرفت ذخیره شد', 'success');
        } else {
            this.showToast('لطفاً تمام فیلدها را پر کنید', 'error');
        }
    }

    calculateBMI(weight, height) {
        const heightInMeters = height / 100;
        return (weight / (heightInMeters * heightInMeters)).toFixed(1);
    }

    displayPlan() {
        if (!this.currentPlan) {
            document.getElementById('plan-container').innerHTML = `
                <div class="empty-state">
                    <p>هنوز برنامه‌ای ایجاد نشده است. ابتدا پروفایل خود را تکمیل کنید.</p>
                    <button class="btn btn-primary" onclick="app.switchSection('profile')">
                        تکمیل پروفایل
                    </button>
                </div>
            `;
            return;
        }

        const planHTML = this.currentPlan.weeks.map(week => `
            <div class="week-plan">
                <div class="week-header">
                    <h3>هفته ${week.weekNumber}</h3>
                    <p class="goal">هدف: ${this.getGoalText(this.currentUser.goal)}</p>
                </div>
                <div class="week-content">
                    ${week.days.map(day => `
                        <div class="day-workout">
                            <div class="day-header">
                                <span class="day-name">${day.name}</span>
                                <span class="day-muscle-groups">${day.muscleGroups.join(', ')}</span>
                            </div>
                            <div class="day-content">
                                ${day.exercises.map(exercise => `
                                    <div class="exercise-item">
                                        <div class="exercise-info">
                                            <div class="exercise-name">${exercise.name}</div>
                                            <div class="exercise-details">
                                                ${exercise.sets} ست × ${exercise.reps} تکرار | ${exercise.rest} استراحت
                                            </div>
                                        </div>
                                        <button class="video-btn" onclick="app.showExerciseVideo('${exercise.name}')">
                                            <svg class="icon" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                                <polygon points="5,3 19,12 5,21"/>
                                            </svg>
                                        </button>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `).join('');

        document.getElementById('plan-container').innerHTML = planHTML;
    }

    displayExercises() {
        const exercisesGrid = document.getElementById('exercises-grid');
        const exercises = window.ExercisesDatabase.getAllExercises();

        const exercisesHTML = exercises.map(exercise => `
            <div class="exercise-card" onclick="app.showExerciseVideo('${exercise.name}')">
                <div class="exercise-header">
                    <h3 class="exercise-title">${exercise.name}</h3>
                    <span class="exercise-muscle-group">${this.getMuscleGroupText(exercise.muscleGroup)}</span>
                </div>
                <div class="exercise-body">
                    <p class="exercise-description">${exercise.description}</p>
                    <div class="exercise-actions">
                        <span class="difficulty-badge difficulty-${exercise.difficulty}">
                            ${this.getDifficultyText(exercise.difficulty)}
                        </span>
                        <button class="btn btn-secondary btn-sm">
                            <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                <polygon points="5,3 19,12 5,21"/>
                            </svg>
                            مشاهده ویدئو
                        </button>
                    </div>
                </div>
            </div>
        `).join('');

        exercisesGrid.innerHTML = exercisesHTML;
    }

    filterExercises(filter) {
        if (filter === 'all') {
            this.displayExercises();
        } else {
            const exercises = window.ExercisesDatabase.getExercisesByMuscleGroup(filter);
            const exercisesGrid = document.getElementById('exercises-grid');

            const exercisesHTML = exercises.map(exercise => `
                <div class="exercise-card" onclick="app.showExerciseVideo('${exercise.name}')">
                    <div class="exercise-header">
                        <h3 class="exercise-title">${exercise.name}</h3>
                        <span class="exercise-muscle-group">${this.getMuscleGroupText(exercise.muscleGroup)}</span>
                    </div>
                    <div class="exercise-body">
                        <p class="exercise-description">${exercise.description}</p>
                        <div class="exercise-actions">
                            <span class="difficulty-badge difficulty-${exercise.difficulty}">
                                ${this.getDifficultyText(exercise.difficulty)}
                            </span>
                            <button class="btn btn-secondary btn-sm">
                                <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                    <polygon points="5,3 19,12 5,21"/>
                                </svg>
                                مشاهده ویدئو
                            </button>
                        </div>
                    </div>
                </div>
            `).join('');

            exercisesGrid.innerHTML = exercisesHTML;
        }
    }

    displayProgress() {
        if (this.progressData.length === 0) {
            document.querySelector('.progress-charts').innerHTML = '<p>هنوز اطلاعاتی ثبت نشده است.</p>';
            document.querySelector('.progress-table').innerHTML = '<p>هنوز اطلاعاتی ثبت نشده است.</p>';
            return;
        }

        // Update table
        const tbody = document.querySelector('#progress-table tbody');
        tbody.innerHTML = this.progressData.map((data, index) => {
            const change = index > 0 ? 
                ((data.weight - this.progressData[index - 1].weight).toFixed(1)) : 
                '0.0';
            const changeClass = index > 0 ? 
                (change > 0 ? 'change-positive' : change < 0 ? 'change-negative' : 'change-neutral') : 
                '';

            return `
                <tr>
                    <td>${data.date.toLocaleDateString('fa-IR')}</td>
                    <td>${data.weight} کیلوگرم</td>
                    <td class="${changeClass}">${change > 0 ? '+' : ''}${change} کیلوگرم</td>
                </tr>
            `;
        }).join('');

        // Update chart if Chart.js is loaded
        if (window.ProgressCharts && window.ProgressCharts.updateChart) {
            window.ProgressCharts.updateChart(this.progressData);
        }
    }

    showExerciseVideo(exerciseName) {
        const exercise = window.ExercisesDatabase.getExerciseByName(exerciseName);
        if (exercise && exercise.videoUrl) {
            // Open video in new tab
            window.open(exercise.videoUrl, '_blank');
        } else {
            // Search for exercise video on YouTube
            const searchQuery = encodeURIComponent(`${exerciseName} exercise tutorial Persian`);
            const youtubeUrl = `https://www.youtube.com/results?search_query=${searchQuery}`;
            window.open(youtubeUrl, '_blank');
        }
    }

    downloadPDF() {
        if (!this.currentPlan || !this.currentUser) {
            this.showToast('ابتدا برنامه تمرینی خود را ایجاد کنید', 'warning');
            return;
        }

        try {
            window.PDFGenerator.generatePlanPDF(this.currentUser, this.currentPlan);
            this.showToast('PDF با موفقیت دانلود شد', 'success');
        } catch (error) {
            console.error('PDF generation error:', error);
            this.showToast('خطا در تولید PDF', 'error');
        }
    }

    getGoalText(goal) {
        const goals = {
            'fat-loss': 'چربی‌سوزی',
            'muscle-gain': 'عضله‌سازی',
            'both': 'چربی‌سوزی و عضله‌سازی',
            'strength': 'افزایش قدرت',
            'endurance': 'استقامت',
            'general': 'تناسب اندام عمومی'
        };
        return goals[goal] || goal;
    }

    getMuscleGroupText(group) {
        const groups = {
            'chest': 'سینه',
            'back': 'پشت',
            'shoulders': 'شانه',
            'arms': 'بازو',
            'legs': 'پا',
            'core': 'شکم',
            'full-body': 'تمام بدن'
        };
        return groups[group] || group;
    }

    getDifficultyText(difficulty) {
        const difficulties = {
            'beginner': 'مبتدی',
            'intermediate': 'متوسط',
            'advanced': 'پیشرفته'
        };
        return difficulties[difficulty] || difficulty;
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <span>${message}</span>
            <button onclick="this.parentElement.remove()" class="toast-close">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <line x1="18" y1="6" x2="6" y2="18"/>
                    <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>
        `;

        document.getElementById('toast-container').appendChild(toast);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 5000);
    }

    saveUserData() {
        if (this.currentUser) {
            localStorage.setItem('fitnessUserData', JSON.stringify(this.currentUser));
        }
    }

    loadUserData() {
        const saved = localStorage.getItem('fitnessUserData');
        if (saved) {
            this.currentUser = JSON.parse(saved);
        }
    }

    saveProgressData() {
        localStorage.setItem('fitnessProgressData', JSON.stringify(this.progressData));
    }

    loadProgressData() {
        const saved = localStorage.getItem('fitnessProgressData');
        if (saved) {
            const data = JSON.parse(saved);
            this.progressData = data.map(item => ({
                ...item,
                date: new Date(item.date)
            }));
        }
    }

    setupPWA() {
        // Register service worker
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js')
                .then(registration => {
                    console.log('SW registered: ', registration);
                })
                .catch(registrationError => {
                    console.log('SW registration failed: ', registrationError);
                });
        }

        // Handle app install prompt
        let deferredPrompt;
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            
            // Show custom install button
            this.showInstallButton(deferredPrompt);
        });
    }

    showInstallButton(deferredPrompt) {
        const installBtn = document.createElement('button');
        installBtn.className = 'install-prompt';
        installBtn.innerHTML = `
            <svg class="icon" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
            </svg>
            نصب اپلیکیشن
        `;
        
        installBtn.addEventListener('click', () => {
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then((choiceResult) => {
                if (choiceResult.outcome === 'accepted') {
                    console.log('User accepted the A2HS prompt');
                }
                deferredPrompt = null;
                installBtn.remove();
            });
        });

        document.querySelector('.app-header').appendChild(installBtn);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new FitnessApp();
    window.app.loadProgressData();
});