// Workout Plan Generator
class WorkoutPlanner {
    constructor(userData) {
        this.userData = userData;
        this.planWeeks = 4; // Default plan duration
        this.exercises = window.ExercisesDatabase;
    }

    generatePlan() {
        const weeks = [];
        
        for (let weekNum = 1; weekNum <= this.planWeeks; weekNum++) {
            const week = this.generateWeek(weekNum);
            weeks.push(week);
        }

        return {
            weeks,
            userInfo: this.userData,
            createdDate: new Date(),
            planDuration: this.planWeeks
        };
    }

    generateWeek(weekNumber) {
        const { goal, experience, daysPerWeek, healthConditions } = this.userData;
        
        // Base workout split based on goal and experience
        const workoutSplit = this.getWorkoutSplit(goal, experience, daysPerWeek);
        
        const week = {
            weekNumber,
            days: [],
            goal: this.getGoalDescription(goal),
            focus: this.getWeeklyFocus(weekNumber, goal)
        };

        for (let dayNum = 0; dayNum < workoutSplit.length; dayNum++) {
            const dayPlan = workoutSplit[dayNum];
            const day = {
                name: dayPlan.name,
                muscleGroups: dayPlan.muscleGroups,
                exercises: this.generateDayExercises(dayPlan, weekNumber, healthConditions),
                duration: this.userData.duration,
                notes: this.getDayNotes(dayPlan, healthConditions)
            };
            week.days.push(day);
        }

        return week;
    }

    getWorkoutSplit(goal, experience, daysPerWeek) {
        const splits = {
            // 3 days per week
            3: {
                'fat-loss': [
                    { name: 'روز اول', muscleGroups: ['تمام بدن'], focus: 'cardio-strength' },
                    { name: 'روز دوم', muscleGroups: ['تمام بدن'], focus: 'cardio-strength' },
                    { name: 'روز سوم', muscleGroups: ['تمام بدن'], focus: 'cardio-strength' }
                ],
                'muscle-gain': [
                    { name: 'روز اول', muscleGroups: ['سینه', 'شانه', 'بازو'], focus: 'upper-body' },
                    { name: 'روز دوم', muscleGroups: ['پشت', 'بازو'], focus: 'upper-body' },
                    { name: 'روز سوم', muscleGroups: ['پا', 'شکم'], focus: 'lower-body' }
                ],
                'both': [
                    { name: 'روز اول', muscleGroups: ['سینه', 'پشت', 'شانه'], focus: 'push-pull' },
                    { name: 'روز دوم', muscleGroups: ['پا', 'بازو'], focus: 'strength' },
                    { name: 'روز سوم', muscleGroups: ['تمام بدن'], focus: 'cardio-strength' }
                ],
                'strength': [
                    { name: 'روز اول', muscleGroups: ['سینه', 'پشت', 'شانه'], focus: 'compound' },
                    { name: 'روز دوم', muscleGroups: ['پا', 'شکم'], focus: 'compound' },
                    { name: 'روز سوم', muscleGroups: ['بازو'], focus: 'accessory' }
                ],
                'general': [
                    { name: 'روز اول', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز دوم', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز سوم', muscleGroups: ['تمام بدن'], focus: 'full-body' }
                ]
            },
            // 4 days per week
            4: {
                'fat-loss': [
                    { name: 'روز اول', muscleGroups: ['سینه', 'بازو'], focus: 'upper-body' },
                    { name: 'روز دوم', muscleGroups: ['پا', 'باسن'], focus: 'lower-body' },
                    { name: 'روز سوم', muscleGroups: ['پشت', 'شانه'], focus: 'upper-body' },
                    { name: 'روز چهارم', muscleGroups: ['تمام بدن'], focus: 'cardio-strength' }
                ],
                'muscle-gain': [
                    { name: 'روز اول', muscleGroups: ['سینه', 'شانه', 'بازو'], focus: 'push' },
                    { name: 'روز دوم', muscleGroups: ['پشت', 'بازو'], focus: 'pull' },
                    { name: 'روز سوم', muscleGroups: ['پا', 'باسن'], focus: 'legs' },
                    { name: 'روز چهارم', muscleGroups: ['تمام بدن'], focus: 'full-body' }
                ],
                'both': [
                    { name: 'روز اول', muscleGroups: ['سینه', 'شانه'], focus: 'push' },
                    { name: 'روز دوم', muscleGroups: ['پشت'], focus: 'pull' },
                    { name: 'روز سوم', muscleGroups: ['پا', 'باسن'], focus: 'legs' },
                    { name: 'روز چهارم', muscleGroups: ['بازو', 'شکم'], focus: 'accessory' }
                ],
                'strength': [
                    { name: 'روز اول', muscleGroups: ['سینه', 'شانه'], focus: 'compound' },
                    { name: 'روز دوم', muscleGroups: ['پشت'], focus: 'compound' },
                    { name: 'روز سوم', muscleGroups: ['پا'], focus: 'compound' },
                    { name: 'روز چهارم', muscleGroups: ['بازو', 'شکم'], focus: 'accessory' }
                ],
                'general': [
                    { name: 'روز اول', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز دوم', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز سوم', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز چهارم', muscleGroups: ['تمام بدن'], focus: 'full-body' }
                ]
            },
            // 5 days per week
            5: {
                'fat-loss': [
                    { name: 'روز اول', muscleGroups: ['سینه'], focus: 'chest' },
                    { name: 'روز دوم', muscleGroups: ['پا', 'باسن'], focus: 'lower-body' },
                    { name: 'روز سوم', muscleGroups: ['پشت'], focus: 'back' },
                    { name: 'روز چهارم', muscleGroups: ['شانه', 'بازو'], focus: 'upper-body' },
                    { name: 'روز پنجم', muscleGroups: ['تمام بدن'], focus: 'cardio-strength' }
                ],
                'muscle-gain': [
                    { name: 'روز اول', muscleGroups: ['سینه'], focus: 'chest' },
                    { name: 'روز دوم', muscleGroups: ['پشت'], focus: 'back' },
                    { name: 'روز سوم', muscleGroups: ['شانه'], focus: 'shoulders' },
                    { name: 'روز چهارم', muscleGroups: ['بازو'], focus: 'arms' },
                    { name: 'روز پنجم', muscleGroups: ['پا', 'شکم'], focus: 'legs-core' }
                ],
                'both': [
                    { name: 'روز اول', muscleGroups: ['سینه'], focus: 'chest' },
                    { name: 'روز دوم', muscleGroups: ['پا', 'باسن'], focus: 'lower-body' },
                    { name: 'روز سوم', muscleGroups: ['پشت'], focus: 'back' },
                    { name: 'روز چهارم', muscleGroups: ['شانه', 'بازو'], focus: 'upper-body' },
                    { name: 'روز پنجم', muscleGroups: ['تمام بدن'], focus: 'cardio-strength' }
                ],
                'strength': [
                    { name: 'روز اول', muscleGroups: ['سینه'], focus: 'chest' },
                    { name: 'روز دوم', muscleGroups: ['پشت'], focus: 'back' },
                    { name: 'روز سوم', muscleGroups: ['شانه'], focus: 'shoulders' },
                    { name: 'روز چهارم', muscleGroups: ['پا'], focus: 'legs' },
                    { name: 'روز پنجم', muscleGroups: ['بازو', 'شکم'], focus: 'accessory' }
                ],
                'general': [
                    { name: 'روز اول', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز دوم', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز سوم', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز چهارم', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز پنجم', muscleGroups: ['تمام بدن'], focus: 'full-body' }
                ]
            },
            // 6 days per week
            6: {
                'fat-loss': [
                    { name: 'روز اول', muscleGroups: ['سینه'], focus: 'chest' },
                    { name: 'روز دوم', muscleGroups: ['پشت'], focus: 'back' },
                    { name: 'روز سوم', muscleGroups: ['پا', 'باسن'], focus: 'lower-body' },
                    { name: 'روز چهارم', muscleGroups: ['شانه'], focus: 'shoulders' },
                    { name: 'روز پنجم', muscleGroups: ['بازو'], focus: 'arms' },
                    { name: 'روز ششم', muscleGroups: ['تمام بدن'], focus: 'cardio-strength' }
                ],
                'muscle-gain': [
                    { name: 'روز اول', muscleGroups: ['سینه'], focus: 'chest' },
                    { name: 'روز دوم', muscleGroups: ['پشت'], focus: 'back' },
                    { name: 'روز سوم', muscleGroups: ['شانه'], focus: 'shoulders' },
                    { name: 'روز چهارم', muscleGroups: ['بازو'], focus: 'arms' },
                    { name: 'روز پنجم', muscleGroups: ['پا'], focus: 'legs' },
                    { name: 'روز ششم', muscleGroups: ['شکم'], focus: 'core' }
                ],
                'both': [
                    { name: 'روز اول', muscleGroups: ['سینه'], focus: 'chest' },
                    { name: 'روز دوم', muscleGroups: ['پشت'], focus: 'back' },
                    { name: 'روز سوم', muscleGroups: ['پا', 'باسن'], focus: 'lower-body' },
                    { name: 'روز چهارم', muscleGroups: ['شانه'], focus: 'shoulders' },
                    { name: 'روز پنجم', muscleGroups: ['بازو'], focus: 'arms' },
                    { name: 'روز ششم', muscleGroups: ['تمام بدن'], focus: 'cardio-strength' }
                ],
                'strength': [
                    { name: 'روز اول', muscleGroups: ['سینه'], focus: 'chest' },
                    { name: 'روز دوم', muscleGroups: ['پشت'], focus: 'back' },
                    { name: 'روز سوم', muscleGroups: ['شانه'], focus: 'shoulders' },
                    { name: 'روز چهارم', muscleGroups: ['پا'], focus: 'legs' },
                    { name: 'روز پنجم', muscleGroups: ['بازو'], focus: 'arms' },
                    { name: 'روز ششم', muscleGroups: ['شکم'], focus: 'core' }
                ],
                'general': [
                    { name: 'روز اول', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز دوم', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز سوم', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز چهارم', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز پنجم', muscleGroups: ['تمام بدن'], focus: 'full-body' },
                    { name: 'روز ششم', muscleGroups: ['تمام بدن'], focus: 'full-body' }
                ]
            }
        };

        return splits[daysPerWeek]?.[goal] || splits[3]['general'];
    }

    generateDayExercises(dayPlan, weekNumber, healthConditions) {
        const { muscleGroups, focus } = dayPlan;
        const { experience } = this.userData;
        
        let exercises = [];
        
        // Get base exercises for muscle groups
        muscleGroups.forEach(group => {
            const groupExercises = this.exercises.getExercisesByMuscleGroup(group);
            
            // Filter based on experience level
            const filteredExercises = groupExercises.filter(ex => {
                if (experience === 'beginner') return ex.difficulty === 'beginner';
                if (experience === 'intermediate') return ex.difficulty !== 'advanced';
                return true; // Advanced can do all
            });

            // Filter based on health conditions
            const safeExercises = filteredExercises.filter(ex => {
                return this.isExerciseSafe(ex, healthConditions);
            });

            exercises.push(...safeExercises.slice(0, 3)); // Max 3 exercises per muscle group
        });

        // Add cardio exercises for fat loss goals
        if (this.userData.goal === 'fat-loss' || focus === 'cardio-strength') {
            const cardioExercises = this.exercises.getCardioExercises();
            exercises.push(...cardioExercises.slice(0, 2));
        }

        // Add core exercises if not already included
        if (!muscleGroups.includes('شکم') && !muscleGroups.includes('تمام بدن')) {
            const coreExercises = this.exercises.getExercisesByMuscleGroup('core');
            exercises.push(...coreExercises.slice(0, 2));
        }

        // Format exercises with sets, reps, and rest
        return exercises.slice(0, 8).map(exercise => {
            const repScheme = this.getRepScheme(exercise, weekNumber, focus);
            return {
                name: exercise.name,
                sets: repScheme.sets,
                reps: repScheme.reps,
                rest: repScheme.rest,
                muscleGroup: exercise.muscleGroup,
                difficulty: exercise.difficulty,
                equipment: exercise.equipment
            };
        });
    }

    getRepScheme(exercise, weekNumber, focus) {
        const { goal, experience } = this.userData;
        
        // Base rep schemes based on goal
        let baseReps, sets, rest;
        
        switch (goal) {
            case 'fat-loss':
                baseReps = focus === 'cardio-strength' ? '15-20' : '12-15';
                sets = 3;
                rest = '30-45 ثانیه';
                break;
            case 'muscle-gain':
                baseReps = experience === 'beginner' ? '8-12' : '6-10';
                sets = experience === 'advanced' ? 4 : 3;
                rest = '60-90 ثانیه';
                break;
            case 'both':
                baseReps = '10-15';
                sets = 3;
                rest = '45-60 ثانیه';
                break;
            case 'strength':
                baseReps = exercise.difficulty === 'advanced' ? '3-5' : '5-8';
                sets = experience === 'advanced' ? 5 : 4;
                rest = '2-3 دقیقه';
                break;
            default:
                baseReps = '10-12';
                sets = 3;
                rest = '60 ثانیه';
        }

        // Progressive overload - increase reps each week
        const weekMultiplier = 1 + (weekNumber - 1) * 0.1;
        const repRange = baseReps.split('-');
        const minRep = Math.floor(parseInt(repRange[0]) * weekMultiplier);
        const maxRep = Math.floor(parseInt(repRange[1]) * weekMultiplier);
        
        return {
            sets,
            reps: `${minRep}-${maxRep}`,
            rest
        };
    }

    isExerciseSafe(exercise, healthConditions) {
        const hasBackPain = healthConditions.includes('back-pain');
        const hasKneeProblems = healthConditions.includes('knee-problems');
        const hasShoulderInjury = healthConditions.includes('shoulder-injury');
        const hasHeartCondition = healthConditions.includes('heart-condition');

        // Skip exercises that might aggravate conditions
        if (hasBackPain && exercise.avoidWithBackPain) return false;
        if (hasKneeProblems && exercise.avoidWithKneeProblems) return false;
        if (hasShoulderInjury && exercise.avoidWithShoulderInjury) return false;
        if (hasHeartCondition && exercise.highIntensity) return false;

        return true;
    }

    getGoalDescription(goal) {
        const descriptions = {
            'fat-loss': 'کاهش چربی بدن و بهبود ترکیب بدنی',
            'muscle-gain': 'افزایش حجم و قدرت عضلانی',
            'both': 'ترکیب چربی‌سوزی و عضله‌سازی',
            'strength': 'افزایش قدرت و توان عضلانی',
            'endurance': 'بهبود استقامت و توان قلبی عروقی',
            'general': 'تناسب اندام کلی و سلامت عمومی'
        };
        return descriptions[goal] || goal;
    }

    getWeeklyFocus(weekNumber, goal) {
        if (goal === 'fat-loss') {
            const focuses = [
                'تطبیق با برنامه تمرینی',
                'افزایش شدت تمرینات',
                'افزایش کالری سوزی',
                'حداکثر چربی‌سوزی'
            ];
            return focuses[weekNumber - 1] || focuses[0];
        } else if (goal === 'muscle-gain') {
            const focuses = [
                'تثبیت فرم صحیح تمرینات',
                'افزایش وزن وزنه‌ها',
                'افزایش حجم تمرینات',
                'حداکثر رشد عضلانی'
            ];
            return focuses[weekNumber - 1] || focuses[0];
        } else {
            const focuses = [
                'تطبیق با برنامه',
                'افزایش شدت تمرین',
                'بهبود ترکیب بدنی',
                'رسیدن به اهداف'
            ];
            return focuses[weekNumber - 1] || focuses[0];
        }
    }

    getDayNotes(dayPlan, healthConditions) {
        let notes = [];
        
        if (healthConditions.includes('back-pain')) {
            notes.push('از تمرینات سنگین کمر خودداری کنید');
        }
        
        if (healthConditions.includes('knee-problems')) {
            notes.push('از تمرینات فشار زیاد بر زانو پرهیز کنید');
        }
        
        if (dayPlan.focus === 'cardio-strength') {
            notes.push('تمرینات کاردیو در ابتدا یا انتهای جلسه');
        }

        return notes.length > 0 ? notes.join(' • ') : null;
    }
}

// Make WorkoutPlanner available globally
window.WorkoutPlanner = WorkoutPlanner;