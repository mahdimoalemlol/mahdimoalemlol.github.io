// PDF Generator for Workout Plans
class PDFGenerator {
    constructor() {
        this.setupPDFLibrary();
    }

    setupPDFLibrary() {
        // We'll use jsPDF for PDF generation
        // This is a mock implementation that would use jsPDF library
        // In a real implementation, you would include jsPDF via CDN
        
        // For now, we'll create a text-based PDF content that can be downloaded
        this.isAvailable = typeof window.jsPDF !== 'undefined' || this.hasCanvasAPI();
    }

    hasCanvasAPI() {
        return typeof document !== 'undefined' && document.createElement;
    }

    generatePlanPDF(userData, workoutPlan) {
        try {
            const pdfContent = this.createPDFContent(userData, workoutPlan);
            this.downloadPDF(pdfContent, userData);
        } catch (error) {
            console.error('PDF generation failed:', error);
            throw error;
        }
    }

    createPDFContent(userData, workoutPlan) {
        const currentDate = new Date().toLocaleDateString('fa-IR');
        
        let content = `
برنامه تمرینی شخصی
====================

تاریخ ایجاد: ${currentDate}
نام: ${userData.name}
سن: ${userData.age} سال
قد: ${userData.height} سانتی‌متر
وزن: ${userData.weight} کیلوگرم
BMI: ${userData.bmi}
جنسیت: ${userData.gender === 'male' ? 'مرد' : 'زن'}

اهداف:
-------
هدف اصلی: ${this.getGoalText(userData.goal)}
سطح تجربه: ${this.getExperienceText(userData.experience)}
روزهای تمرین در هفته: ${userData.daysPerWeek} روز
مدت هر جلسه: ${userData.duration} دقیقه

`;

        if (userData.healthConditions && userData.healthConditions.length > 0) {
            content += `
شرایط پزشکی:
-------------
${userData.healthConditions.map(condition => 
    `• ${this.getHealthConditionText(condition)}`
).join('\n')}

`;
        }

        if (userData.additionalNotes) {
            content += `
توضیحات اضافی:
--------------
${userData.additionalNotes}

`;
        }

        // Add workout weeks
        workoutPlan.weeks.forEach(week => {
            content += `\nهفته ${week.weekNumber}
==============

هدف: ${week.goal}
تمرکز: ${week.focus}

`;

            week.days.forEach((day, dayIndex) => {
                content += `\n${day.name}
${'='.repeat(day.name.length)}
گروه‌های عضلانی: ${day.muscleGroups.join(', ')}
مدت تخمینی: ${day.duration} دقیقه

`;

                if (day.notes) {
                    content += `نکات: ${day.notes}\n\n`;
                }

                day.exercises.forEach(exercise => {
                    content += `• ${exercise.name}\n`;
                    content += `  ${exercise.sets} ست × ${exercise.reps} تکرار\n`;
                    content += `  استراحت: ${exercise.rest}\n`;
                    content += `  گروه عضلانی: ${this.getMuscleGroupText(exercise.muscleGroup)}\n`;
                    content += `  تجهیزات: ${exercise.equipment}\n\n`;
                });
            });
        });

        // Add exercise library
        content += `\n\nراهنمای تمرینات
===============

`;

        const exercises = window.ExercisesDatabase.getAllExercises();
        const muscleGroups = ['chest', 'back', 'shoulders', 'arms', 'legs', 'core'];
        
        muscleGroups.forEach(group => {
            content += `\n${this.getMuscleGroupText(group)}
${'='.repeat(this.getMuscleGroupText(group).length)}

`;
            
            const groupExercises = exercises.filter(ex => ex.muscleGroup === group);
            groupExercises.forEach(exercise => {
                content += `• ${exercise.name} (${this.getDifficultyText(exercise.difficulty)})\n`;
                content += `  ${exercise.description}\n`;
                content += `  تجهیزات: ${exercise.equipment}\n\n`;
            });
        });

        // Add tips
        content += `\nنکات مهم
========

• قبل از شروع تمرین، 5-10 دقیقه گرم کنید
• از وزن شروع کنید که بتوانید با فرم صحیح انجام دهید
• بین ست‌ها کامل استراحت کنید
• آب کافی بنوشید
• در صورت احساس درد، فوراً متوقف شوید
• برای گرفتن بهترین نتیجه، منظم باشید
• هر 2-3 هفته برنامه خود را تغییر دهید

`;

        // Add emergency contacts
        content += `\nاطلاعات تماس اضطراری
=======================

در صورت بروز هرگونه مشکل یا سوال، با مربی خود تماس بگیرید.

`;

        return content;
    }

    downloadPDF(content, userData) {
        try {
            // Create a blob with the content
            const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
            
            // Create download link
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `برنامه_تمرینی_${userData.name}_${new Date().toISOString().split('T')[0]}.txt`;
            
            // Trigger download
            document.body.appendChild(link);
            link.click();
            
            // Cleanup
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);
            
        } catch (error) {
            console.error('Download failed:', error);
            // Fallback: open content in new window
            const newWindow = window.open();
            newWindow.document.write(`
                <html>
                <head>
                    <title>برنامه تمرینی</title>
                    <style>
                        body { font-family: 'Vazirmatn', Arial, sans-serif; direction: rtl; text-align: right; padding: 20px; line-height: 1.6; }
                        pre { white-space: pre-wrap; }
                    </style>
                </head>
                <body>
                    <pre>${content}</pre>
                </body>
                </html>
            `);
        }
    }

    // Alternative HTML to PDF conversion using print
    printWorkoutPlan(userData, workoutPlan) {
        const printWindow = window.open('', '_blank');
        const html = this.createPrintHTML(userData, workoutPlan);
        
        printWindow.document.write(html);
        printWindow.document.close();
        
        // Trigger print after content loads
        setTimeout(() => {
            printWindow.print();
        }, 1000);
    }

    createPrintHTML(userData, workoutPlan) {
        return `
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>برنامه تمرینی</title>
    <style>
        body {
            font-family: 'Vazirmatn', Arial, sans-serif;
            direction: rtl;
            text-align: right;
            line-height: 1.6;
            margin: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 15px;
        }
        .week {
            page-break-before: always;
            margin-bottom: 40px;
        }
        .day {
            margin-bottom: 25px;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 5px;
        }
        .exercise {
            margin-bottom: 10px;
            padding: 5px;
            background: #f5f5f5;
            border-radius: 3px;
        }
        .user-info, .health-conditions {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>برنامه تمرینی شخصی</h1>
        <p><strong>تاریخ ایجاد:</strong> ${new Date().toLocaleDateString('fa-IR')}</p>
    </div>

    <div class="user-info">
        <h2>اطلاعات شخصی</h2>
        <p><strong>نام:</strong> ${userData.name}</p>
        <p><strong>سن:</strong> ${userData.age} سال</p>
        <p><strong>قد:</strong> ${userData.height} سانتی‌متر</p>
        <p><strong>وزن:</strong> ${userData.weight} کیلوگرم</p>
        <p><strong>BMI:</strong> ${userData.bmi}</p>
        <p><strong>هدف:</strong> ${this.getGoalText(userData.goal)}</p>
        <p><strong>سطح تجربه:</strong> ${this.getExperienceText(userData.experience)}</p>
    </div>

    ${userData.healthConditions && userData.healthConditions.length > 0 ? `
        <div class="health-conditions">
            <h2>شرایط پزشکی</h2>
            <ul>
                ${userData.healthConditions.map(condition => 
                    `<li>${this.getHealthConditionText(condition)}</li>`
                ).join('')}
            </ul>
        </div>
    ` : ''}

    ${workoutPlan.weeks.map(week => `
        <div class="week">
            <h2>هفته ${week.weekNumber}</h2>
            <p><strong>هدف:</strong> ${week.goal}</p>
            <p><strong>تمرکز:</strong> ${week.focus}</p>
            
            ${week.days.map(day => `
                <div class="day">
                    <h3>${day.name}</h3>
                    <p><strong>گروه‌های عضلانی:</strong> ${day.muscleGroups.join(', ')}</p>
                    <p><strong>مدت:</strong> ${day.duration} دقیقه</p>
                    
                    ${day.notes ? `<p><strong>نکات:</strong> ${day.notes}</p>` : ''}
                    
                    <h4>تمرینات:</h4>
                    ${day.exercises.map(exercise => `
                        <div class="exercise">
                            <strong>${exercise.name}</strong>
                            <br>${exercise.sets} ست × ${exercise.reps} تکرار
                            <br>استراحت: ${exercise.rest}
                            <br>تجهیزات: ${exercise.equipment}
                        </div>
                    `).join('')}
                </div>
            `).join('')}
        </div>
    `).join('')}

    <div style="margin-top: 50px; page-break-before: avoid;">
        <h2>نکات مهم</h2>
        <ul>
            <li>قبل از شروع تمرین، 5-10 دقیقه گرم کنید</li>
            <li>از وزن شروع کنید که بتوانید با فرم صحیح انجام دهید</li>
            <li>بین ست‌ها کامل استراحت کنید</li>
            <li>آب کافی بنوشید</li>
            <li>در صورت احساس درد، فوراً متوقف شوید</li>
            <li>برای گرفتن بهترین نتیجه، منظم باشید</li>
        </ul>
    </div>

    <button class="no-print" onclick="window.print()" style="margin-top: 20px; padding: 10px 20px; background: #2196F3; color: white; border: none; border-radius: 5px; cursor: pointer;">
        چاپ برنامه
    </button>
</body>
</html>`;
    }

    getGoalText(goal) {
        const goals = {
            'fat-loss': 'چربی‌سوزی',
            'muscle-gain': 'عضله‌سازی',
            'both': 'چربی‌سوزی و عضله‌سازی',
            'strength': 'افزایش قدرت',
            'endurance': 'استقامت',
            'general': 'تناسب اندام عمومی'
        };
        return goals[goal] || goal;
    }

    getExperienceText(experience) {
        const experiences = {
            'beginner': 'مبتدی (0-6 ماه)',
            'intermediate': 'متوسط (6 ماه - 2 سال)',
            'advanced': 'پیشرفته (بیش از 2 سال)'
        };
        return experiences[experience] || experience;
    }

    getHealthConditionText(condition) {
        const conditions = {
            'back-pain': 'کمر درد',
            'knee-problems': 'مشکلات زانو',
            'shoulder-injury': 'آسیب شانه',
            'heart-condition': 'مشکلات قلبی',
            'diabetes': 'دیابت',
            'hypertension': 'فشار خون بالا'
        };
        return conditions[condition] || condition;
    }

    getMuscleGroupText(group) {
        const groups = {
            'chest': 'سینه',
            'back': 'پشت',
            'shoulders': 'شانه',
            'arms': 'بازو',
            'legs': 'پا',
            'core': 'شکم',
            'full-body': 'تمام بدن'
        };
        return groups[group] || group;
    }

    getDifficultyText(difficulty) {
        const difficulties = {
            'beginner': 'مبتدی',
            'intermediate': 'متوسط',
            'advanced': 'پیشرفته'
        };
        return difficulties[difficulty] || difficulty;
    }
}

// Make PDFGenerator available globally
window.PDFGenerator = new PDFGenerator();